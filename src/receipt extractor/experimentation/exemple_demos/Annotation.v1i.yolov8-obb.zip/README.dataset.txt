# Annotation > 2024-03-07 7:14pm
https://universe.roboflow.com/myworkspace-844r3/annotation-0lhvl

Provided by a Roboflow user
License: CC BY 4.0

